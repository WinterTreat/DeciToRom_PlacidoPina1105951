﻿namespace arabic2Roman;

public class Arabic2Roman
{
    public static string Converter(string arabicNum)
    {

        if (string.IsNullOrWhiteSpace(arabicNum))
        { return "Input cannot be null or whitespace."; }

        if(!int.TryParse(arabicNum, out int arabicNumINT))
        { return "Input is not a valid integer."; }

        if(arabicNumINT <=0 || arabicNumINT >= 4000)
        { return "Number must be between 1 and 3999."; }


        var romanNumerals = new Dictionary<int, string>
        {
            { 1000, "M" }, { 900, "CM" }, { 500, "D" }, { 400, "CD" }, { 100, "C" },
            { 90, "XC" }, { 50, "L" }, { 40, "XL" }, { 10, "X" }, { 9, "IX" },
            { 5, "V" }, { 4, "IV" }, { 1, "I" }
        };

        var result = string.Empty;

        foreach (var item in romanNumerals)
        {
            while (arabicNumINT >= item.Key)
            {
                result += item.Value;
                arabicNumINT -= item.Key;
            }
        }

        return result;
    }
}
