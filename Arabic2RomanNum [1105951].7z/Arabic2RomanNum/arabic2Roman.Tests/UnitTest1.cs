namespace arabic2Roman.Tests;

[TestClass]
public class ValidInputs
{
    [TestMethod]
    public void TestMethod1()
    {
        string result = arabic2Roman.Arabic2Roman.Converter("1");
        Assert.AreEqual("I", result);
    }

    [TestMethod]
    public void TestMethod2()
    {
        string result = arabic2Roman.Arabic2Roman.Converter("2");
        Assert.AreEqual("II", result);
    }

    [TestMethod]
    public void TestMethod3()
    {
        string result = arabic2Roman.Arabic2Roman.Converter("3");
        Assert.AreEqual("III", result);
    }
        
    [TestMethod]
    public void TestMethod4()
    {
        string result = arabic2Roman.Arabic2Roman.Converter("4");
        Assert.AreEqual("IV", result);
    }

    [TestMethod]
    public void TestMethod5()
    {
        string result = arabic2Roman.Arabic2Roman.Converter("5");
        Assert.AreEqual("V", result);
    }

    [TestMethod]
    public void TestMethod6()
    {
        string result = arabic2Roman.Arabic2Roman.Converter("10");
        Assert.AreEqual("X", result);
    }

    [TestMethod]
    public void TestMethod7()
    {
        string result = arabic2Roman.Arabic2Roman.Converter("20");
        Assert.AreEqual("XX", result);
    }

    [TestMethod]
    public void TestMethod8()
    {
        string result = arabic2Roman.Arabic2Roman.Converter("30");
        Assert.AreEqual("XXX", result);
    }

    [TestMethod]
    public void TestMethod9()
    {
        string result = arabic2Roman.Arabic2Roman.Converter("40");
        Assert.AreEqual("XL", result);
    }

    [TestMethod]
    public void TestMethod10()
    {
        string result = arabic2Roman.Arabic2Roman.Converter("50");
        Assert.AreEqual("L", result);
    }

    [TestMethod]
    public void TestMethod11()
    {
        string result = arabic2Roman.Arabic2Roman.Converter("100");
        Assert.AreEqual("C", result);
    }
}


[TestClass]
public class InvalidInputsTests
{
    [TestMethod]
    public void IsNullOrWhiteSpace()
    {
        string result = arabic2Roman.Arabic2Roman.Converter(" ");
        Assert.AreEqual("Input cannot be null or whitespace.", result);
    }

    [TestMethod]
    public void InvalidInput()
    {
        string result = arabic2Roman.Arabic2Roman.Converter("a");
        Assert.AreEqual("Input is not a valid integer.", result);
    }

    [TestMethod]
    public void OutOfRange()
    {
        string result = arabic2Roman.Arabic2Roman.Converter("-1");
        Assert.AreEqual("Number must be between 1 and 3999.", result);
    }
}